// ==UserScript==
// @name LikeIGiveAFuck
// @include http://*.facebook.*
// @include https://*.facebook.*
// @require jquery.min.js
// ==/UserScript==

console.log("It Works!");
var likeLinks = [];

setInterval(function() {
	likeLinks = $( '.UFILikeLink' );
	changeText(likeLinks);
},2200)

function changeText(likeLinks) {
	likeLinks.each(function( i ) {
		if( $( this ).attr('data-ft') == '{"tn":">"}' ) {
			$( this ).text('I give a Fuck').css('background', 'green');
		}
		else if( $( this ).attr('data-ft') == '{"tn":"?"}' ) {
			$( this ).text('I don’t give a Fuck').css('background', 'red');
		}
	});
}