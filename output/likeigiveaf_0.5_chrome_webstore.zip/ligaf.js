// ==UserScript==
// @name Like I Give A Fuck
// @include http://*.facebook.*
// @include https://*.facebook.*
// @require jquery.min.js
// ==/UserScript==

console.log("LIKE I GIVE A F***!");
changeLinks( $('#substream_0 .UFILikeLink') );
changeLinks( $('#substream_1 .UFILikeLink') );

var target = document.querySelector('body');
var config = { childList: true, attributes: true, characterData: true, subtree: true };
var observer = new MutationObserver(function(mutations) {
  mutations.forEach(function(mutation) {

    if( mutation.attributeName === 'data-ft' ) {
      changeLinks( $(mutation.target) ); 
    }


    $(mutation.addedNodes).each(function() {
      var UFILikeLinks  = $( '.UFILikeLink', this );

      if( UFILikeLinks.length ) {
      	changeLinks( $( '.UFILikeLink', this ) );
      }


      var UFILikeSentenceText = $( '.UFILikeSentenceText > span > *', this);

      if( UFILikeSentenceText.length > 1 ) {
        if( UFILikeSentenceText.length == 2 && UFILikeSentenceText.hasClass('profileLink') ) {
          UFILikeSentenceText.last().text(' gives a fuck.');
        } else {
          UFILikeSentenceText.last().text(' give a fuck.');
        }
      } else {
        UFILikeSentenceText.last().text('You give a fuck.');
      }
    });

  });    
});

observer.observe(target, config);

function changeLinks(likeLinks) {
    likeLinks.each(function() {
    if( $( this ).attr('data-ft') == '{"tn":">"}' ) {
      $( this ).text('I give a Fuck');
    }
    else if( $( this ).attr('data-ft') == '{"tn":"?"}' ) {
      $( this ).text('I don’t give a Fuck');
    }
  });
}